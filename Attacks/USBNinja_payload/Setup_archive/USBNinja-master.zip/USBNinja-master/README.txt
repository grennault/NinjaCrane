#USBNinja

USBNinja Main Software Project

This is the USBNinja`s Main Software Project. You can easily clone it and Change it by yourself.

-------------------------------------------------------------------------------
How to Complete/Install?

Take it easy, It don`t need to complete. You can put the JSON under the Arduino`s User Profile Folder and put other files
in the Hardware folder. Then, you can use Arduino IDE to complete the Applications.

What`s USBNinja?

The USBNinja is a USB Cable that embedded an BADUSB in it. It has 6KB Flash Memory in it to store your own payload.
These payloads can be triggered by a Bluetooth Remote Control or this Application. The Cable can simulate itself to an
HID-Keyboard or an HID-Mouse to Control your computer.

How can I buy it?

You can get more information on https://usbninja.com