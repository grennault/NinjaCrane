#ifndef Arduino_h
#define Arduino_h
#include <WProgram.h>
extern int USBninjaOffline(void);
extern int USBninjaOnline(void); 
extern void SetRunOnce(int,bool);
#endif